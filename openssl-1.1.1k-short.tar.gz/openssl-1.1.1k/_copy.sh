sudo cp -f libcrypto.so.1.1 /usr/lib/
sudo cp -f libssl.so.1.1 /usr/lib/
sudo cp -f libMagicCrypto.so /usr/lib/

sudo ln -s -f /usr/lib/libcrypto.so.1.1 /usr/lib/libcrypto.so
sudo ln -s -f /usr/lib/libssl.so.1.1 /usr/lib/libssl.so

sudo cp -f apps/openssl /usr/bin/


